# REST-API-DEVLOPMENT
I developed rest api using spring boot ,maven and jdbc. In this project we retrieved the information about bridges.
